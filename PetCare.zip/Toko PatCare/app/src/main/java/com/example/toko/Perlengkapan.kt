package com.example.toko

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream

class Perlengkapan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan)

        val rv_perlengkapan:RecyclerView = findViewById(R.id.rv_perlengkapan)

        val id_perlengkapan:MutableList<String> = mutableListOf();
        val nama:MutableList<String> = mutableListOf();
        val deskripsi:MutableList<String> = mutableListOf();
        val harga:MutableList<String> = mutableListOf();
        val foto:MutableList<Bitmap> = mutableListOf();

        //Pangil Database
        val dbtoko:SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)

        val gali_produk = dbtoko.rawQuery("SELECT * FROM perlengkapan", null)
        while (gali_produk.moveToNext()) {

            try {
                val bis = ByteArrayInputStream(gali_produk.getBlob(4))
                val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            } catch (e:Exception) {
                val gambarbitmap: Bitmap = BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                foto.add(gambarbitmap)
            }

            id_perlengkapan.add(gali_produk.getString(0))
            nama.add(gali_produk.getString(1))
            deskripsi.add(gali_produk.getString(2))
            harga.add(gali_produk.getString(3))
        }

        val mi = Perlengkapan_item( this, id_perlengkapan, nama, deskripsi, harga, foto)
        rv_perlengkapan.adapter = mi
        rv_perlengkapan.layoutManager = GridLayoutManager(this, 2)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah:Intent = Intent(this, Perlengkapan_tambah::class.java)
            startActivity(pindah)
        }

        val btn_back:Button = findViewById(R.id.btn_back)
        btn_back.setOnClickListener {
            val kembali:Intent = Intent(this, Dashboard::class.java)
            startActivity(kembali)
            finish()
        }
    }
}