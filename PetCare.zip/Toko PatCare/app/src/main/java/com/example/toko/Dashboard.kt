package com.example.toko

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard);

        val card_makanan:CardView = findViewById(R.id.card_makanan)
        val card_obat:CardView = findViewById(R.id.card_obat)
        val card_perlengkapan:CardView = findViewById(R.id.card_perlengkapan)
        val txt_pelogin:TextView = findViewById(R.id.txt_pelogin)

        val tiket:SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
        val nama_pelogin:String = tiket.getString("nama_admin", null).toString()
        txt_pelogin.text = nama_pelogin

        val btn_logout:Button = findViewById(R.id.btn_logout)
        btn_logout.setOnClickListener {
            val edittiket= tiket.edit()
            edittiket.clear()
            edittiket.commit()

            val keluar:Intent = Intent(this, Login::class.java)
            startActivity(keluar)
            finish()
        }

        card_makanan.setOnClickListener {
            val pindah:Intent = Intent(this, Makanan::class.java)
            startActivity(pindah);
        }

        card_obat.setOnClickListener {
            val pindah:Intent = Intent(this, Obat::class.java)
            startActivity(pindah)
        }
        card_perlengkapan.setOnClickListener {
            val pindah:Intent = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }

    }
}