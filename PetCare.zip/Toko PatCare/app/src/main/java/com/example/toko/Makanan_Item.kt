package com.example.toko

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Makanan_Item (val ini:Context, val id_makanan:MutableList<String>, val nama:MutableList<String>, val diskripsi:MutableList<String>, val harga:MutableList<String>, val foto:MutableList<Bitmap>) : RecyclerView.Adapter<Makanan_Item.ViewHolder>(){
    //Dapatkan Layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
    val view = LayoutInflater.from(parent.context).inflate(R.layout.makanan_item, parent, false)
    return ViewHolder(view)
    }
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val txt_nama:TextView = ItemView.findViewById(R.id.txt_nama)
        val txt_deskripsi:TextView = ItemView.findViewById(R.id.txt_deskripsi)
        val txt_harga:TextView = ItemView.findViewById(R.id.txt_harga)
        val iv_foto:ImageView = ItemView.findViewById(R.id.iv_foto)
        val btn_hapus:Button = ItemView.findViewById(R.id.btn_hapus)
        val btn_edit:Button = ItemView.findViewById(R.id.btn_edit)
    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_nama.text = nama.get(position)
        holder.txt_deskripsi.text = diskripsi.get(position)
        holder.txt_harga.text = harga.get(position)
        holder.iv_foto.setImageBitmap(foto.get(position))

        holder.btn_hapus.setOnClickListener {
            val id_makanan_terpilih:String = id_makanan.get(position)

            val pindah:Intent = Intent(ini,Makanan_Hapus::class.java)
            pindah.putExtra("id_makanan_terpilih", id_makanan_terpilih)
            ini.startActivity(pindah)
        }

        holder.btn_edit.setOnClickListener {
            val id_makanan_terpilih:String = id_makanan.get(position)

            val pindah:Intent = Intent(ini,Makanan_Ubah::class.java)
            pindah.putExtra("id_makanan_terpilih", id_makanan_terpilih)
            ini.startActivity(pindah)
        }

    }

}