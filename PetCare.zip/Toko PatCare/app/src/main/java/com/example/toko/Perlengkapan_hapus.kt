package com.example.toko

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Perlengkapan_hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan_hapus)

        val id_perlengkapan_terpilih:String = intent.getStringExtra("id_perlengkapan_terpilih").toString()

        val dbtoko: SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)

        val query = dbtoko.rawQuery("DELETE FROM perlengkapan WHERE kode_perlengkapan='$id_perlengkapan_terpilih'", null)
        query.moveToNext()

        val pindah:Intent = Intent(this,Perlengkapan::class.java)
        startActivity(pindah)
    }
}