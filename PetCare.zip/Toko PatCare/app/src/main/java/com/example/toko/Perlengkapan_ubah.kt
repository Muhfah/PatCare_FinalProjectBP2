package com.example.toko

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class Perlengkapan_ubah : AppCompatActivity() {

    var urlgambar:Uri? = null
    var bitmapgambar:Bitmap? = null
    var iv_foto:ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan_ubah)

        val id_perlengkapan_terpilih:String = intent.getStringExtra("id_perlengkapan_terpilih").toString()

        val dbtoko:SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)
        val ambil = dbtoko.rawQuery("SELECT * FROM perlengkapan WHERE kode_perlengkapan = '$id_perlengkapan_terpilih' ", null)
        ambil.moveToNext()

        val isi_nama:String = ambil.getString(1)
        val isi_deskripsi:String = ambil.getString(2)
        val isi_harga:String = ambil.getString(3)
        val isi_foto:ByteArray = ambil.getBlob(4)

        val edt_nama:EditText = findViewById(R.id.edt_nama)
        val edt_deskripsi:EditText = findViewById(R.id.edt_deskripsi)
        val edt_harga:EditText = findViewById(R.id.edt_harga)
        val btn_simpan:Button = findViewById(R.id.btn_simpan)

        iv_foto = findViewById(R.id.iv_foto)

        edt_nama.setText(isi_nama)
        edt_deskripsi.setText(isi_deskripsi)
        edt_harga.setText(isi_harga)

        try {
            val bis = ByteArrayInputStream(isi_foto)
            val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
            iv_foto?.setImageBitmap(gambarbitmap)
        } catch (e:Exception) {
            val gambarbitmap: Bitmap = BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
            iv_foto?.setImageBitmap(gambarbitmap)
        }

        iv_foto?.setOnClickListener {
            val bukagaleri:Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pilih_gambar.launch(bukagaleri)
        }

        btn_simpan.setOnClickListener {
            val nama_baru:String = edt_nama.text.toString()
            val deskripsi_baru:String = edt_deskripsi.text.toString()
            val harga_baru:String = edt_harga.text.toString()

            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG,100, bos)
            val bytearraygambar = bos.toByteArray()

            val sql = "UPDATE perlengkapan SET nama_perlengkapan=?, deskripsi_perlengkapan=?, harga_perlengkapan=?, gambar_perlengkapan=? WHERE kode_perlengkapan='$id_perlengkapan_terpilih'"
            val statement = dbtoko.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, isi_nama)
            statement.bindString(2, isi_deskripsi)
            statement.bindString(3, isi_harga)
            statement.bindBlob(4, bytearraygambar)
            statement.executeUpdateDelete()

            val pindah:Intent = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }

    }
    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode== Activity.RESULT_OK) {
            val gambardiperoleh = it.data

            if (gambardiperoleh!=null) {
                val urlgambar = gambardiperoleh.data

                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_foto?.setImageBitmap(bitmapgambar)

            }
        }
    }
}