package com.example.toko

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayOutputStream

class Perlengkapan_tambah : AppCompatActivity() {

    var urlgambar: Uri? = null
    var bitmapgambar: Bitmap? = null
    var iv_foto: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perlengkapan_tambah)

        val edt_nama:EditText = findViewById(R.id.edt_nama)
        val edt_deskripsi:EditText = findViewById(R.id.edt_deskripsi)
        val edt_harga:EditText = findViewById(R.id.edt_harga)
        val btn_simpan:Button = findViewById(R.id.btn_simpan)

        iv_foto = findViewById(R.id.iv_foto)

        iv_foto?.setOnClickListener {
            val bukagaleri:Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pilih_gambar.launch(bukagaleri)
        }

        btn_simpan.setOnClickListener {
            val isi_nama:String = edt_nama.text.toString()
            val isi_deskripsi:String = edt_deskripsi.text.toString()
            val isi_harga:String = edt_harga.text.toString()

            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG,100, bos)
            val bytearraygambar = bos.toByteArray()

            val dbkampus:SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)

            val sql = "INSERT INTO perlengkapan (nama_perlengkapan,deskripsi_perlengkapan,harga_perlengkapan,gambar_perlengkapan) VALUES (?,?,?,?)"
            val statement = dbkampus.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, isi_nama)
            statement.bindString(2, isi_deskripsi)
            statement.bindString(3, isi_harga)
            statement.bindBlob(4, bytearraygambar)
            statement.executeInsert()

            //pindah halaman lagi
            val pindah:Intent = Intent(this, Perlengkapan::class.java)
            startActivity(pindah)
        }
    }
    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode== Activity.RESULT_OK) {
            val gambardiperoleh = it.data

            if (gambardiperoleh!=null) {
                val urlgambar = gambardiperoleh.data

                bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_foto?.setImageBitmap(bitmapgambar)

            }
        }
    }
}