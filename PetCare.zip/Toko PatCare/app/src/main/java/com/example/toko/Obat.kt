package com.example.toko

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream

class Obat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.obat)

        val rv_obat:RecyclerView = findViewById(R.id.rv_obat)

        val id_obat:MutableList<String> = mutableListOf();
        val nama:MutableList<String> = mutableListOf();
        val deskripsi:MutableList<String> = mutableListOf();
        val harga:MutableList<String> = mutableListOf();
        val foto:MutableList<Bitmap> = mutableListOf();

        //Pangil Database
        val dbtoko:SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)

        val gali_produk = dbtoko.rawQuery("SELECT * FROM obat", null)
        while (gali_produk.moveToNext()) {

            try {
                val bis = ByteArrayInputStream(gali_produk.getBlob(4))
                val gambarbitmap:Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            } catch (e:Exception) {
                val gambarbitmap:Bitmap = BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                foto.add(gambarbitmap)
            }

            id_obat.add(gali_produk.getString(0))
            nama.add(gali_produk.getString(1))
            deskripsi.add(gali_produk.getString(2))
            harga.add(gali_produk.getString(3))
        }

        val mi = Obat_item( this, id_obat, nama, deskripsi, harga, foto)
        rv_obat.adapter = mi
        rv_obat.layoutManager = GridLayoutManager(this, 2)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah:Intent = Intent(this, Obat_tambah::class.java)
            startActivity(pindah)
        }

        val btn_back:Button = findViewById(R.id.btn_back)
        btn_back.setOnClickListener {
            val kembali:Intent = Intent(this, Dashboard::class.java)
            startActivity(kembali)
            finish()
        }
    }
}