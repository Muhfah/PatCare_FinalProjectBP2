package com.example.toko

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream

class Makanan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.makanan)

        val rv_makanan:RecyclerView = findViewById(R.id.rv_makanan)

        val id_makanan:MutableList<String> = mutableListOf();
        val nama:MutableList<String> = mutableListOf();
        val deskripsi:MutableList<String> = mutableListOf();
        val harga:MutableList<String> = mutableListOf();
        val foto:MutableList<Bitmap> = mutableListOf();

        //Pangil Database
        val dbtoko:SQLiteDatabase = openOrCreateDatabase("toko", MODE_PRIVATE, null)

        val gali_produk = dbtoko.rawQuery("SELECT * FROM makanan", null)
        while (gali_produk.moveToNext()) {

            try {
                val bis = ByteArrayInputStream(gali_produk.getBlob(4))
                val gambarbitmap:Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            } catch (e:Exception) {
                val gambarbitmap:Bitmap = BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                foto.add(gambarbitmap)
            }

            id_makanan.add(gali_produk.getString(0))
            nama.add(gali_produk.getString(1))
            deskripsi.add(gali_produk.getString(2))
            harga.add(gali_produk.getString(3))
        }

        val mi = Makanan_Item( this, id_makanan, nama, deskripsi, harga, foto)
        rv_makanan.adapter = mi
        rv_makanan.layoutManager = GridLayoutManager(this, 2)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah:Intent = Intent(this, Makanan_Tambah::class.java)
            startActivity(pindah)
        }

        val btn_back:Button = findViewById(R.id.btn_back)
        btn_back.setOnClickListener {
            val kembali:Intent = Intent(this, Dashboard::class.java)
            startActivity(kembali)
            finish()
        }
    }
}